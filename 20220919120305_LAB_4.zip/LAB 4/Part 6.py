y = input('Input words separating them with only spaces: ')
if y == '':
    exit()
x = y.split()
N = len(x)
for i in range(0, N - 1):
    for j in range(i + 1, N):
        w = x[i]
        r = x[j]
        a = w.lower()
        v = r.lower()
        g = sorted(a)
        h = sorted(v)
        if h == g:
            print(x[i], x[j])
