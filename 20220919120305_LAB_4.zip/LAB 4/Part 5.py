y = input('input a list of number separating them by , :')
u = y.replace(',','')
print(u)
x = u.split()
print(x)
p = []
for index in range(len(x)):
    p.append(float(x[index]))
    print(p)
p.sort()
max1 = p[-1]
max2 = p[-2]
print(max1, max2)

