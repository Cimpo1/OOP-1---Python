
result = 0
for i in range(10001):
    d = i%13
    if d == 0:
        result +=i
print(result)
