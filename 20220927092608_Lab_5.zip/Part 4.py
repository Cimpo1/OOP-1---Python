x = range(1001)
y = []
u = []
for i in range(1001):
    if x[i] == 0:
        y.append(False)
    elif x[i] == 1:
        y.append(False)
    else:
        y.append(True)
for i in range(2,int((1000**(1/2))+1)):
    if y[i]:
        for j in range(i**2,1001, i):
                y[j]=False
for i in range(0,1001):
    if y[i] == True:
        u.append(i)
print(len(u))
