n = input('Input the names and bids: ')
h = n.split(',')
mk = h
km = tuple(mk)
print(h)
final = []
while len(h) != 0:
    y=h.pop()
    r=y.split()
    u = r.pop()
    final.append(u)
print(final)
final2=[int(x) for x in final]
final2=final2[::-1]
print(final2)
print(max(final2))
j = max(final2)
k = final2.index(max(final2))
print(k)
print(km[k])
uy = list(km)
iu = uy[k]
ui = iu.split(' ')
print('The highest bid is',ui[1] ,', and it was first placed by',ui[0] ,'.')
