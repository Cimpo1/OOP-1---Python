result = 0
for i in range(10001):
    d = i%13
    f = i%7
    if d == 0:
        result +=i
    elif f == 0:
        result += i
print(result)
