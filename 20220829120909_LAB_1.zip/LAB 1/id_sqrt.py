x = 2130140
y = 1000
abs(y*y-x) < 1e-3
y = (y + x / y) / 2
y = (y + x / y) / 2
y = (y + x / y) / 2
y = (y + x / y) / 2
y = (y + x / y) / 2
y = (y + x / y) / 2
print("The square root of", x, "is", y)
