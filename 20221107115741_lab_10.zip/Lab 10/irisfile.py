'''Module for accessing the file iris.txt, containing
data used in the classic paper:

 Fisher,R.A. "The use of multiple measurements in taxonomic problems"
 Annual Eugenics, 7, Part II, 179-188 (1936)

This module will export a function that reads the data file into a list
of lists.
'''

N_FIELDS = 5                    # number of items on each row in the file.

# Indices of the fields.
SEPAL_LENGTH = 0
SEPAL_WIDTH = 1
PETAL_LENGTH = 2
PETAL_WIDTH = 3
SPECIES = 4

N_SPECIES = 3

# Codes for the species.
IRIS_SETOSA = "Iris-setosa"
IRIS_VERSICOLOR = "Iris-versicolor"
IRIS_VIRGINICA = "Iris-virginica"
SPECIES_NAMES = (IRIS_SETOSA, IRIS_VERSICOLOR, IRIS_VIRGINICA)

def field_index_to_name(index):
    '''Converts a field index to a human-readable name.'''
    field_names = ('sepal length', 'sepal width', 'petal length', 'petal width', 'species')
    if index < 0 or index >= N_FIELDS:
        return "invalid field"
    return field_names[index]
    
def get_column(data, col):
    '''Extract a particular column of data from the data object.'''
    return [fields[col] for fields in data]

def get_species(data, species):
    '''Extract only the data associated with a particular species.'''
    return [fields for fields in data if fields[-1] == species]

def iris_data():
    '''Opens the data file and converts the contents into a Python "list
    of lists."

    Each data line in the file looks like this:

    5.0 3.3 1.4 0.2 Iris-setosa

    The 5 fields are as follows:
    1. the sepal length in cm
    2. the sepal width in cm
    3. the petal length in cm
    4. the petal width in cm. 
    5. the latin name of the species, either:
        Iris-setosa, Iris-versicolor, or Iris-virginica

    The file may also contain comment lines that begin with a '#'
    character. Your code must ignore these!

    '''
    file = open('iris.txt')
    data = []
    for line in file:
        # READ THE CONTENTS OF THE FILE HERE
        # 1. You must ignore lines that start with a hash '#' character.
        if line[0] == '#':
            continue
        # 2. You must process each line by splitting it into fields, and then
        # converting the fields into numeric types. You will then append
        # the list of fields onto the end of the data list.
        else:
            y = line.strip()
            f = y.split(' ')
            z = []
            for g in range(0,4):   
                x = float(f[g])
                z.append(x)
            z.append(f[4])
            data.append(z)
            
            
            
        # 3. If you do everything correctly, you should have a list of
        # 150 sublists, and each sublist should contain 5 items. The
        # first sublist will correspond to the first line in the file, so
        # it should contain [5.1, 3.5, 1.4, 0.2, "Iris-setosa"]. The first
        # four items correspond to the float measurements. The final item is
        # the name of the species, IRIS_SETOSA.
        pass
    file.close()
    return data                 # This should be a list of lists.
