# 1. -1.0
#2. Error / did not accept my writing
#3 restart done
#4. -1.0 / imported only cos and pi
#5. ERROR / math.cos is not needed anymore
#6. -1.0 / imported everything
from irisfile import *
from statistics import stdev, mean
import matplotlib.pyplot as plt

data = iris_data()
sepal_length = get_column(data, SEPAL_LENGTH)
sepal_width = get_column(data, SEPAL_WIDTH)
petal_length = get_column(data, PETAL_LENGTH)
petal_width = get_column(data, PETAL_WIDTH)
sl = []
sw = []
pl = []
pw = []

sl.append(min(sepal_length))
sl.append(max(sepal_length))
sl.append(mean(sepal_length))
sl.append(stdev(sepal_length))

sw.append(min(sepal_width))
sw.append(max(sepal_width))
sw.append(mean(sepal_width))
sw.append(stdev(sepal_width))

pl.append(min(petal_length))
pl.append(max(petal_length))
pl.append(mean(petal_length))
pl.append(stdev(petal_length))

pw.append(min(petal_width))
pw.append(max(petal_width))
pw.append(mean(petal_width))
pw.append(stdev(petal_width))

fp = open('summary.txt', 'w')

print('Combined data :', file = fp)
print('  sepal length: {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*sl), file = fp)
print('  sepal width : {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*sw), file = fp)
print('  petal length: {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*pl), file = fp)
print('  petal width : {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*pw), file = fp)

tmp = get_species(data, IRIS_SETOSA)
Ssepal_length = get_column(tmp, SEPAL_LENGTH)
Ssepal_width = get_column(tmp, SEPAL_WIDTH)
Spetal_length = get_column(tmp, PETAL_LENGTH)
Spetal_width = get_column(tmp, PETAL_WIDTH)
Ssl = []
Ssw = []
Spl = []
Spw = []

Ssl.append(min(Ssepal_length))
Ssl.append(max(Ssepal_length))
Ssl.append(mean(Ssepal_length))
Ssl.append(stdev(Ssepal_length))

Ssw.append(min(Ssepal_width))
Ssw.append(max(Ssepal_width))
Ssw.append(mean(Ssepal_width))
Ssw.append(stdev(Ssepal_width))

Spl.append(min(Spetal_length))
Spl.append(max(Spetal_length))
Spl.append(mean(Spetal_length))
Spl.append(stdev(Spetal_length))

Spw.append(min(Spetal_width))
Spw.append(max(Spetal_width))
Spw.append(mean(Spetal_width))
Spw.append(stdev(Spetal_width))

print('For Species Iris-setosa :', file = fp)
print('  sepal length: {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*Ssl), file = fp)
print('  sepal width : {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*Ssw), file = fp)
print('  petal length: {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*Spl), file = fp)
print('  petal width : {0:.1f} {1:.1f} {2:.2f} {3:.2f}'.format(*Spw), file = fp)
fp.close()

colors = ('red', 'blue', 'green')
names = []

j = 0
while j<=2:
    names.append(SPECIES_NAMES[j])
    s = get_species(data, SPECIES_NAMES[j])
    x = get_column(s, PETAL_LENGTH)
    y = get_column(s, PETAL_WIDTH)
    plt.scatter(x, y, color = colors[j])
    j += 1
    
plt.xlabel('petal length, cm')
plt.ylabel('petal width, cm')
plt.title('David Cimpoiasu, 2130140')
plt.legend(names)
plt.show()
