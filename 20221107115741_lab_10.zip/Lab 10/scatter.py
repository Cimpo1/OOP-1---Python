import matplotlib.pyplot as plt

from irisfile import *

data = iris_data()

colors = ('red', 'blue', 'green')

# List of names used in the 'legend' below.
names = []

j = 0
names.append(SPECIES_NAMES[j])
s = get_species(data, SPECIES_NAMES[j])
x = get_column(s, PETAL_LENGTH)
y = get_column(s, PETAL_WIDTH)
plt.scatter(x, y, color = colors[j])
    
plt.xlabel('petal length, cm')
plt.ylabel('petal width, cm')

plt.legend(names)
plt.show()
