# This is a very simple example of plotting a line,
# using sin() and cos().
#
# See if you can increase the "frequency" of either
# curve, to show more than one cycle of the function.
#
from math import sin, cos, pi
import matplotlib.pyplot as plt

# In plotting a continuous curve, we still need to select a finite number
# of points to plot. A value of 100 is enough to create a smooth-looking
# curve.
    
N = 100 

# Create a vector of values for the x axis, from 0 to 2 pi
x = []
for i in range(N):
    x.append(2 * pi * i / N)

# Compute the y axis values for sin()
y = []
for v in x:
    y.append(sin(v))
plt.plot(x, y, color='red')

y = []
for v in x:
    y.append(cos(v))
plt.plot(x, y, color='blue')

plt.legend(['sine', 'cosine'])
plt.show()
