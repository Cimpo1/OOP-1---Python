# Creates a bar chart for the iris data.
#
# This will only work when your iris_data() function is complete.
#
import matplotlib.pyplot as plt
from irisfile import *
from statistics import mean

data = iris_data()

# Colors for the individual species.

colors = ('red', 'blue', 'green')

# List of names used in the 'legend' below.
names = []

# Create the figure and axes.
figure, axes = plt.subplots()

# Sets the width of each bar.
width = 1 / (N_SPECIES + 1)

# Create the bars for each species.
for j in range(N_SPECIES):
    s = get_species(data, SPECIES_NAMES[j])
    x = []
    y = []
    for k in range(N_FIELDS-1):
        x.append(k + width * j)
        y.append(mean(get_column(s, k)))

    axes.bar(x, y, width, color = colors[j])
    names.append(SPECIES_NAMES[j])
axes.legend(names)

# Create the "tick labels" along the x axis.
xticks = []
xticklabels = []
for k in range(N_FIELDS-1):
    xticks.append(k + width)
    xticklabels.append(field_index_to_name(k))
axes.set_xticks(xticks)
axes.set_ylabel('cm')
axes.set_xticklabels(xticklabels)
plt.show()
