"""
David Cimpoiasu
420-LCU-05 Computer Programming , Section 1
Fall 2022
R. Vincent , instructor
Assignment 1, Exercise 1
"""
import time # to slow down program
INT_L = 1 # low
INT_H = 128 # high
print('Please think of a number between an including', INT_L, 'and', INT_H) #user input
time.sleep(2) # Let user think of a number
GUESS = ((INT_H - INT_L)//2)+INT_L #Making the guess
x = '' # input variable begin loop
while x != 'c': # loop for program to run until the right number
    print('Is your secret number',GUESS,'?') # Asking user
    x = input("Enter ’h’ if my guess is too high, ’l’ if too low, or ’c’ if I am correct:") # Input for determinating high low or correct
    if x == 'h': # Processing the input high
        INT_H = GUESS
        GUESS = (((INT_H) - INT_L)//2)+INT_L #remaking guess
    elif x == 'l': #processing input low
        INT_L = GUESS
        GUESS = (((INT_H+1) - INT_L)//2)+INT_L #remaking guess adjusted to be able to have 128
    elif x == 'c': #processing input correct
        print('Your secret number is', GUESS) #end
    else:
        print('Please input a valid input.') # User error proofing
print('Goodbye!')
time.sleep(1)
exit()
        
# needs at most 8 guesses (when your secret number is 128)
    