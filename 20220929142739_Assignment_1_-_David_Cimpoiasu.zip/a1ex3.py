"""
David Cimpoiasu
420-LCU-05 Computer Programming , Section 1
Fall 2022
R. Vincent , instructor
Assignment 1, Exercise 3
"""
x = '' # input to enter loop
while x != 'q': #loop to continuously receive input
    x = input('Type a positive integer or ’q’ to quit:') #user input
    if x == 'q': # quit function
        print('Bye!')
    elif x.isnumeric() and int(x) > 0: # user error proofing
        u = int(x) # str to int variable
        dev = []
        for t in range(1,u): 
            if u%t == 0:      # Processing number to get perfect quotients
                dev.append(t)
        if sum(dev) == u:				#sum of perfect quotients compared to number to know if its perfect
            print(u,'is perfect.')
        elif sum(dev) > u:				#sum of perfect quotients compared to number to know if its abundant
            print(u,'is abundant.')
        elif sum(dev) < u:				#sum of perfect quotients compared to number to know if its deficient
            print(u, 'is deficient.')
    else:
        print('Enter a number greater than zero.') # part of user error proofing
exit()