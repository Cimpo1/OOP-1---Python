x = input('Enter password:')
o = []
if ' ' in x:
    print('INVALID')
    exit()
if len(x)<10:
    print('INVALID')
    exit()
if (len(x)<16):
    y= []
    if '$' in x:
        y.append(True)
    if '*' in x:
        y.append(True)
    if '&' in x:
        y.append(True)
    if '%' in x:
        y.append(True)
    if '#' in x:
        y.append(True)
    z = []
    if '1' in x:
        z.append(True)
    if '2' in x:
        z.append(True)
    if '3' in x:
        z.append(True)
    if '4' in x:
        z.append(True)
    if '5' in x:
        z.append(True)
    if '6' in x:
        z.append(True)
    if '7' in x:
        z.append(True)
    if '8' in x:
        z.append(True)
    if '9' in x:
        z.append(True)    
    if any(z) and any(y):
        o.append(True)
        print('VALID')
if len(x)>16:
    o.append(True)
    print('VALID')
if any(o) != True:
    print('INVALID')
    
        