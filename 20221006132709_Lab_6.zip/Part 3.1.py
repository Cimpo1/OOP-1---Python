result = []
z = 1
y = 1
for x in range(1000):
    y = x%3
    z = x%5
    if y == 0:
        if x < 1000:
            result.append(x)
    elif z == 0:
        if x < 1000:
            result.append(x)
print(sum(result))
