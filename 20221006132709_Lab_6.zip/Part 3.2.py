y = 'y'
while y == 'y':
    x = int(input('Enter a year: '))
    if (x>1582) and (((x%4 == 0) and (x%100 != 0)) or ((x%400 == 0) and (x%100== 0))):
        print('It is a leap year')
    elif x <= 1582:
        print('Invalid year')
    else:
        print('It is not a leap year')
    y = input('Restart? y/n')
print('Goodbye')
exit()