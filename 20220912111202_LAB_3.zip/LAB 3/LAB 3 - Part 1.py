x = int(input('Input the first number: '))
y = int(input('Input the second number: '))
while y != 0:
    xr = y
    yr = x%y
    x = xr
    y = yr
print('The answer is ',x ,'.')
#1.  67
#2.  307
#3.  1039
#4.  2027
