w = float(input('Please enter your weight in Kg: '))
h = float(input('Please enter your height in M: '))
x = w/(h**2)
if x > 25:
    print('Your BMI is high.')
elif x < 18.5:
    print('Your BMI is low.')
else:
    print('Your BMI is normal.')
