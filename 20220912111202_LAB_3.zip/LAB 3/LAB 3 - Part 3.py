x = 'y'
while x == 'y':
    n = int(input('Input an integer: '))
    p = 2
    while p <= n**(0.5):
        while (n%p) == 0:
            print(p)
            n = n//p
        if p == 2:
            p = 3
        else:
            p = p+2
    if n>1:
        print(n)
    x = str(input('\n\nDo you want to restart? y/n: '))
exit()
#1. 17  101  3331
#2. 1907 3121 4273
#3. 252971 372689
#4. 197010707 197011127
#5. 3 259511641 1999007957
        
